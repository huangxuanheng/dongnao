# custom-error-pages

Example of Custom error pages for the NGINX Ingress controller
