package edu.dongnao.study.balancer.lesson6_plus;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

/**
 * UploadController
 * 文件上传控制类
 */
@Controller
public class UploadController {
	private static final Logger LOGGER = LoggerFactory.getLogger(UploadController.class);
	private static final String basePath = UploadController.class.getResource("/").getPath();
	@GetMapping("/upload")
	public String upload() {
		return "upload.html";
	}

	@PostMapping("/upload")
	@ResponseBody
	public String upload(@RequestParam("file") MultipartFile file) {
		if (file == null || file.isEmpty()) {
			return "上传失败，请选择文件";
		}
		String fileName = file.getOriginalFilename();
		
		String filePath = basePath + "/data/upload/temp/";
		String uuid = UUID.randomUUID().toString();
		String newName = uuid+fileName;
		try {
			File dest = new File(filePath + newName);
			if(!dest.getParentFile().exists()) {
				dest.getParentFile().mkdirs();
			}
			if(! dest.exists()) {
				dest.createNewFile();
			}
			file.transferTo(dest);
			LOGGER.info("上传成功");
			return "上传成功";
		} catch (IOException e) {
			LOGGER.error(e.toString(), e);
		}
		return "上传失败！";
	}

}
